<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    Welcome <br>
                    <?php if($submit == 'essay' || $submit == 'photo'): ?>
                    	<?php if(!empty($url)): ?>
                        			<p style="color: green">You have <?php echo e($ran); ?> Uploaded your file. To view visit <a href="<?php echo e($url); ?>" target="_blank">here</a></p><br>
                        			<p style="color: green">Go <a href="<?php echo e($link); ?>">Home</a></p>
                        <?php endif; ?>
                        <?php if(empty($url)): ?>
                    	<form method="POST" enctype="multipart/form-data" action="/store/<?php echo e($submit); ?>">
                        <?php echo csrf_field(); ?>
                        	<div class="form-group row">
                            	<label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Project Name')); ?></label>

                            	<div class="col-md-6">
                                	<input id="name" type="text" name="project_name" required autofocus>
                            	</div>
                            </div>
                            <div class="form-group row">
                            	<label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                            	<div class="col-md-6">
                                	<input id="description" type="text" name="description" required autofocus>
                            	</div>
                        	</div>
                        	<div class="form-group row mb-0">
                    			<div class="col-md-8 offset-md-4">
                    				<p style="color: red"><?php if(!empty($err)): ?> <?php echo e($err); ?> <?php endif; ?></p>
                        			<input id="<?php echo e($submit); ?>" type="file" name="<?php echo e($submit); ?>" accept="application/pdf" required autofocus>
                        		</div>
                    		</div>
                    		<div class="form-group row mb-0">
                    			<div class="col-md-8 offset-md-4">
                        			<button type = "submit" class="btn btn-primary" style=" margin-top: 20px;width: 70%;">
                                    <?php echo e(__('Submit')); ?>

                        			</button>
                        		</div>
                    		</div>

                    	</form>
                    	<?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>